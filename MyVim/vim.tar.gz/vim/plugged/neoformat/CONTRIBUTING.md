# contributing

If you are looking to add or update a formatter, please be sure to update both
[`doc/neoformat.txt`](./doc/neoformat.txt) as well as [`README.md`](./README.md). Thanks!
